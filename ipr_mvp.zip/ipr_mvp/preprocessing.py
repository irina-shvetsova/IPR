"""
Модуль предобработки результатов опроса 360°.

Принимает CSV-выгрузку и собирает структурированный профиль сотрудника:
компетенции, деструкторы, оценки ролей и качественные комментарии. Этот
профиль — единственный количественный источник для генерации ИПР.

Ожидаемый формат CSV (колонки; порядок не важен, регистр заголовков игнорируется):

    тип,название,оценка,комментарий
    компетенция,Профессионализм,9.5,
    компетенция,Визионерство,6.3,
    деструктор,Бескомпромиссность,4.2,
    роль,Наставник,8.3,
    роль,Советник,10.0,
    комментарий,,,«системность, погружённость в проект»

Колонка `тип` помогает отличить компетенции от деструкторов, ролей и
свободных комментариев. Числа принимаются и с точкой, и с запятой.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from io import StringIO


# Допустимые значения колонки «тип» и их канонизация
_TYPE_ALIASES = {
    "компетенция": "competency",
    "компетенции": "competency",
    "competency": "competency",
    "деструктор": "destructor",
    "деструкторы": "destructor",
    "destructor": "destructor",
    "роль": "role",
    "роли": "role",
    "role": "role",
    "комментарий": "comment",
    "комментарии": "comment",
    "comment": "comment",
}

_COLUMN_ALIASES = {
    "тип": "type", "type": "type", "категория": "type",
    "название": "name", "name": "name", "компетенция": "name", "показатель": "name",
    "оценка": "score", "score": "score", "балл": "score", "значение": "score",
    "комментарий": "comment", "comment": "comment", "примечание": "comment",
}


@dataclass
class ScoredItem:
    """Оценённый показатель: компетенция, деструктор или роль."""

    name: str
    score: float
    comment: str = ""


@dataclass
class Profile360:
    """Структурированный профиль по результатам опроса 360°."""

    competencies: list[ScoredItem] = field(default_factory=list)
    destructors: list[ScoredItem] = field(default_factory=list)
    roles: list[ScoredItem] = field(default_factory=list)
    qualitative_comments: list[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return not (self.competencies or self.destructors or self.roles)

    def lowest_competencies(self, limit: int = 3) -> list[ScoredItem]:
        """Возвращает зоны роста — компетенции с самыми низкими оценками."""
        return sorted(self.competencies, key=lambda x: x.score)[:limit]

    def top_destructors(self, limit: int = 3) -> list[ScoredItem]:
        """Возвращает самые заметные деструкторы (с наибольшими оценками)."""
        return sorted(self.destructors, key=lambda x: x.score, reverse=True)[:limit]

    def to_prompt_block(self) -> str:
        """
        Готовит читаемый текстовый блок профиля для вставки в промпт.

        В анализ идут только компетенции и оценки ролей. Деструкторы намеренно
        не передаются модели: методология работы с ними отличается, и их разбор
        выведен за рамки текущей версии продукта.
        """
        lines: list[str] = []

        if self.competencies:
            lines.append("КОМПЕТЕНЦИИ:")
            for item in sorted(self.competencies, key=lambda x: x.score, reverse=True):
                lines.append(f"- {item.name} — {_ru_number(item.score)}")

        if self.roles:
            lines.append("\nОЦЕНКИ РОЛЕЙ:")
            for item in self.roles:
                lines.append(f"- {item.name} — {_ru_number(item.score)}")

        return "\n".join(lines)


def _ru_number(value: float) -> str:
    """Форматирует число в русском десятичном формате с одним знаком: 9,5 / 9,0."""
    return f"{value:.1f}".replace(".", ",")


def _clean_text(raw) -> str:
    """Приводит значение к строке, считая nan/none/пусто пустой строкой."""
    if raw is None:
        return ""
    text = str(raw).strip()
    if text.lower() in ("nan", "none", "null", "<na>"):
        return ""
    return text


def _parse_score(raw) -> float | None:
    """Аккуратно приводит значение оценки к float, принимая запятую и точку."""
    if raw is None:
        return None
    text = str(raw).strip().replace(",", ".")
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _normalize_row(row: dict) -> dict:
    """Приводит ключи строки к каноническим именам type/name/score/comment."""
    normalized: dict = {}
    for col, value in row.items():
        if col is None:
            continue
        key = str(col).strip().lower().lstrip("\ufeff")
        normalized[_COLUMN_ALIASES.get(key, key)] = value
    return normalized


def parse_360_csv(file_bytes: bytes) -> Profile360:
    """
    Разбирает CSV-выгрузку 360° и возвращает структурированный профиль.

    Устойчив к кодировкам utf-8 и cp1251 и к разделителям «,» и «;».

    Args:
        file_bytes: Содержимое загруженного CSV-файла.

    Returns:
        Profile360 с разнесёнными по типам показателями.

    Raises:
        ValueError: Если файл не удалось прочитать ни одним из вариантов.
    """
    rows = _read_rows(file_bytes)
    rows = [_normalize_row(r) for r in rows]

    if not rows or not any("name" in r or "score" in r for r in rows):
        raise ValueError(
            "Не найдены колонки с названием и оценкой. "
            "Ожидаются колонки: тип, название, оценка, комментарий."
        )

    profile = Profile360()

    for row in rows:
        raw_type = _clean_text(row.get("type", "")).lower()
        item_type = _TYPE_ALIASES.get(raw_type, "")
        name = _clean_text(row.get("name", ""))
        comment = _clean_text(row.get("comment", ""))
        score = _parse_score(row.get("score"))

        # Свободный комментарий без оценки
        if item_type == "comment" or (not name and comment):
            if comment:
                profile.qualitative_comments.append(comment)
            continue

        if score is None or not name:
            # Строка без оценки или без названия — собираем комментарий, если он есть
            if comment:
                profile.qualitative_comments.append(comment)
            continue

        item = ScoredItem(name=name, score=score, comment=comment)

        if item_type == "destructor":
            profile.destructors.append(item)
        elif item_type == "role":
            profile.roles.append(item)
        else:
            # По умолчанию считаем строку компетенцией
            profile.competencies.append(item)

        if comment:
            profile.qualitative_comments.append(comment)

    return profile


def _read_rows(file_bytes: bytes) -> list[dict]:
    """
    Читает CSV стандартной библиотекой, перебирая кодировки и разделители.

    Namedtuple/DataFrame не используются намеренно: pandas и pyarrow — тяжёлые
    нативные зависимости, а для разбора небольшой выгрузки достаточно csv.
    """
    last_error: Exception | None = None
    for encoding in ("utf-8-sig", "utf-8", "cp1251"):
        try:
            text = file_bytes.decode(encoding)
        except Exception as exc:  # noqa: BLE001 — пробуем следующую кодировку
            last_error = exc
            continue

        for sep in (",", ";", "\t"):
            try:
                reader = csv.DictReader(StringIO(text), delimiter=sep)
                if not reader.fieldnames or len(reader.fieldnames) < 2:
                    continue
                rows = [row for row in reader]
                if rows:
                    return rows
            except Exception as exc:  # noqa: BLE001 — перебираем варианты чтения
                last_error = exc
                continue

    raise ValueError(f"Не удалось прочитать CSV: {last_error or 'формат не распознан'}")
